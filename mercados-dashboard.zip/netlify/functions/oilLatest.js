
// /.netlify/functions/oilLatest
// Usa OilPriceAPI para obter histórico e calcular variações
// Requer OILPRICEAPI_TOKEN

const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));

exports.handler = async (event) => {
  try{
    const token = process.env.OILPRICEAPI_TOKEN;
    if(!token) return { statusCode:500, body: JSON.stringify({error:'Missing OILPRICEAPI_TOKEN'}) };
    const code = (event.queryStringParameters && event.queryStringParameters.code) || 'BRENT_CRUDE_USD';
    const end = new Date(); const start = new Date(Date.now()-400*24*3600*1000);
    const url = `https://api.oilpriceapi.com/v1/prices/historical?code=${encodeURIComponent(code)}&start=${start.toISOString().slice(0,10)}&end=${end.toISOString().slice(0,10)}&interval=daily`;
    const res = await fetch(url, { headers: { 'Authorization': `Token ${token}` } });
    const data = await res.json();
    const series = (data.data && data.data.prices) || (data.data) || [];
    // series esperado: [{timestamp:"2025-12-29T..", price: 74.5}, ...]
    if (!series.length) throw new Error('No oil data');
    series.sort((a,b)=> new Date(a.timestamp)-new Date(b.timestamp));
    const last = series[series.length-1].price;
    function findPast(days){
      const target = new Date(Date.now()-days*24*3600*1000);
      // mais próximo
      let best = series[0]; let bestDiff = Math.abs(new Date(series[0].timestamp)-target);
      for(const p of series){ const diff = Math.abs(new Date(p.timestamp)-target); if (diff<bestDiff){ best=p; bestDiff=diff; } }
      return best.price;
    }
    const changes = {
      d1: ((last - findPast(1))/findPast(1))*100,
      d7: ((last - findPast(7))/findPast(7))*100,
      d30: ((last - findPast(30))/findPast(30))*100,
      d365: ((last - findPast(365))/findPast(365))*100
    };
    return { statusCode:200, body: JSON.stringify({ code, price:last, changes }) };
  }catch(e){
    return { statusCode:500, body: JSON.stringify({error:e.message}) };
  }
};
