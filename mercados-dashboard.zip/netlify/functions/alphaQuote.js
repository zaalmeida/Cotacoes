
// /.netlify/functions/alphaQuote
// Usa Alpha Vantage TIME_SERIES_DAILY para calcular variações 24h, 7d, 30d, 1y
// Requer variável de ambiente: ALPHA_VANTAGE_KEY

const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));

exports.handler = async (event) => {
  try {
    const key = process.env.ALPHA_VANTAGE_KEY;
    if(!key) return { statusCode: 500, body: JSON.stringify({error:'Missing ALPHA_VANTAGE_KEY'}) };
    const symbol = (event.queryStringParameters && event.queryStringParameters.symbol) || 'MSFT';
    const url = `https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=${encodeURIComponent(symbol)}&apikey=${key}`;
    const res = await fetch(url); const data = await res.json();
    const ts = data['Time Series (Daily)'] || data['time series'] || {};
    const dates = Object.keys(ts).sort();
    if(!dates.length) throw new Error('No data');
    const lastDate = dates[dates.length-1];
    const last = parseFloat(ts[lastDate]['4. close']);
    function findPast(days){
      const target = new Date(Date.now()-days*24*3600*1000);
      // procurar a data útil mais recente <= target
      for (let i=dates.length-1; i>=0; i--){
        const d = new Date(dates[i]+ 'T00:00:00Z');
        if (d <= target) return parseFloat(ts[dates[i]]['4. close']);
      }
      return parseFloat(ts[dates[0]]['4. close']);
    }
    const changes = {
      d1: ((last - findPast(1))/findPast(1))*100,
      d7: ((last - findPast(7))/findPast(7))*100,
      d30: ((last - findPast(30))/findPast(30))*100,
      d365: ((last - findPast(365))/findPast(365))*100
    };
    return { statusCode: 200, body: JSON.stringify({ symbol, price:last, changes }) };
  } catch (e) {
    return { statusCode: 500, body: JSON.stringify({ error: e.message }) };
  }
};
